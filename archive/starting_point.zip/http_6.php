<?php

use HTTP_PHP as GlobalHTTP_PHP;

require_once("request.php");
require_once("response.php");

class HTTP_PHP
{
    private $params_data = null;
    function __construct(string $url="")
    {
    }
    function router(String $pattern, $handler)
    {
        // ? check handler
        // if METHOD and pattern not matched
        // ! add new patter checker
        if (!$this->router_route($pattern)) return;

        $http = new HTTP_PHP();

        // execute the handler function
        $handler($http);
        exit();
    }
    function get(String $pattern, $handler)
    {
        // ? check handler
        // if METHOD and pattern not matched
        if ($_SERVER["REQUEST_METHOD"] !== "GET") return;
        if (!$this->route($pattern)) return;

        // if matched create Request Response
        $Request = new Request($this->params_data);
        $Response = new Response();

        // execute the handler function
        $handler($Request, $Response);
        exit();
    }
    function post(String $pattern, $handler)
    {
        // ? check handler
        // if METHOD and pattern not matched
        if ($_SERVER["REQUEST_METHOD"] !== "POST") return;
        if (!$this->route($pattern)) return;

        // if matched create Request Response
        $Request = new Request($this->params_data);
        $Response = new Response();

        // execute the handler function
        $handler($Request, $Response);
        exit();
    }
    function put(String $pattern, $handler)
    {
        // ? check handler
        // if METHOD and pattern not matched
        if ($_SERVER["REQUEST_METHOD"] !== "PUT") return;
        if (!$this->route($pattern)) return;

        // if matched create Request Response
        $Request = new Request($this->params_data);
        $Response = new Response();

        // execute the handler function
        $handler($Request, $Response);
        exit();
    }
    function delete(String $pattern, $handler)
    {
        // ? check handler
        // if METHOD and pattern not matched
        if ($_SERVER["REQUEST_METHOD"] !== "DELETE") return;
        if (!$this->route($pattern)) return;

        // if matched create Request Response
        $Request = new Request($this->params_data);
        $Response = new Response();

        // execute the handler function
        $handler($Request, $Response);
        exit();
    }
    function route(String $pattern)
    {
        // ? check pattern
        // remove url querys
        $url = explode("?", $_SERVER['REQUEST_URI']);

        // trim extra slash
        $url = rtrim($url[0], "/");
        $pattern = rtrim($pattern, "/");

        // separate all params
        $pattern_array = explode("/", $pattern);
        $url_array = explode("/", $url);

        // is params length not matched then return false
        if (count($pattern_array) !== count($url_array)) return false;

        // check all request url params one by one
        foreach ($url_array as $key => $value) {

            // if pattern param not variable
            if (!preg_match_all("/:/i", $pattern_array[$key])) {

                // if param not match then return false
                if ($pattern_array[$key] != $value) return false;
            } else {

                // if pattern param are variable
                // ? clean the params
                $param_key = ltrim($pattern_array[$key], ":");
                $this->params_data[$param_key] = $value;
            }
        }
        return true;
    }
    function router_route(String $pattern)
    {
        // ? check pattern
        // remove url querys
        $url = explode("?", $_SERVER['REQUEST_URI']);

        // trim extra slash
        $url = rtrim($url[0], "/");
        $pattern = rtrim($pattern, "/");

        // separate all params
        $pattern_array = explode("/", $pattern);
        $url_array = explode("/", $url);

        // is params length not matched then return false
        if (count($pattern_array) !== count($url_array)) {
            if (count($pattern_array) <= count($url_array)) {
                // check all pattern param one by one
                foreach ($pattern_array as $key => $value) {

                    // if param not match then return false
                    if ($url_array[$key] != $value) return false;

                    // // if pattern param not variable
                    // if (!preg_match_all("/:/i", $pattern_array[$key])) {
                    // } else {

                    //     // if pattern param are variable
                    //     // ? clean the params
                    //     $param_key = ltrim($pattern_array[$key], ":");
                    //     $this->params_data[$param_key] = $value;
                }
                return true;
            }
            return false;
        } else {
            // check all request url params one by one
            foreach ($url_array as $key => $value) {

                // if pattern param not variable
                if (!preg_match_all("/:/i", $pattern_array[$key])) {

                    // if param not match then return false
                    if ($pattern_array[$key] != $value) return false;
                } else {

                    // if pattern param are variable
                    // ? clean the params
                    $param_key = ltrim($pattern_array[$key], ":");
                    $this->params_data[$param_key] = $value;
                }
            }
            return true;
        }
    }
}





// * ################## Extra Function ##################
