<?php
function file_parser($file_path, $data = null)
{

    // get absulute path
    $file_path = join(DIRECTORY_SEPARATOR, array($_SERVER['DOCUMENT_ROOT'], $file_path));

    // check is file exists
    // if (!file_exists($file_path)) return "Cant Find File";
    if (!file_exists($file_path)) return false;

    // fetch content from file
    $content = file_get_contents($file_path);

    // check is data type array
    if (gettype($data) != "array") return $content;


    // parse parameter
    foreach ($data as $key => $value) {
        $content = str_replace('{{ ' . $key . ' }}', $value, $content);
    }
    return $content;
}
function content_merger($content_array = null)
{
    $content = null;

    // check is data type array
    if (gettype($content_array) != "array") return null;

    // merge all content
    foreach ($content_array as $value) {
        $content .=  $value;
    }
    return $content;
}


// cleaner function 
function cleanInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
