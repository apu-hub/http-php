<?php
class HTTP_PHP
{
    function __construct()
    {
    }
    function get(String $pattern, $handler)
    {
        // if not matched
        if (!$this->route($pattern)) {
            echo "<br>not";
            return;
        }

        // if matched
        echo "<br>match";
        $aka = "fg";
        $Request = new Request();
        $Response = new Response();
        $handler($Request, $Response);
        exit();
    }
    function route(String $pattern)
    {
        $url = explode("?", $_SERVER['REQUEST_URI']);
        $url = rtrim($url[0], "/");
        $pattern = rtrim($pattern, "/");
        // $this->clean_url($url);
        echo "<br> pattern = " . $pattern . "<br>";
        echo "url = " . $url . "<br>";

        if ($pattern === $url)
            return true;
        else
            return false;
    }
    // clean the url
    // ! sample
    // /ab/ or /ab or /ab///
    function clean_url(String $url)
    {
    }

    function request_body()
    {
    }
}
// namespace src/http/Request;
class Request
{
    private $body_data = null;
    private $query_data = null;
    private $params_data = null;
    function __construct()
    {
        // ! add input error handler
        $this->body_data = json_decode(file_get_contents('php://input'), true);
        $this->query_data = $_REQUEST;
    }
    function clean_input($input)
    {
        return $input;
    }
    function body(String $input = "")
    {
        if (isset($input) && !empty($input)) {
            if (isset($this->body_data[$input]) && !empty($this->body_data[$input])) {
                // echo "1";
                return $this->clean_input($this->body_data[$input]);
            } else {
                // echo "2";
                return null;
            }
        } else {
            // echo "3";
            return $this->body_data;
        }
    }
    function query(String $key = "")
    {
        if (isset($key) && !empty($key)) {
            if (isset($this->query_data[$key]) && !empty($this->query_data[$key])) {
                // echo "1";
                return $this->clean_input($this->query_data[$key]);
            } else {
                // echo "2";
                return null;
            }
        } else {
            // echo "3";
            return $this->query_data;
        }
    }
    function params()
    {
        return "Request params";
    }
}
class Response
{
    function __construct()
    {
    }
    function send()
    {
    }
    function status()
    {
    }
    function json()
    {
    }
    function render()
    {
    }
}
